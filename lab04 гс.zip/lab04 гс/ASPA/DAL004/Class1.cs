﻿using Newtonsoft.Json;

namespace DAL004
{
    public record Celebrity(int Id, string Firstname, string Surname, string PhotoPath);
    public interface IRepository : IDisposable
    {
        string BasePath { get; }
        Celebrity[] getAllCelebrities();
        Celebrity? getCelebrityById(int id);
        Celebrity[] getCelebrityBySurname(string Surname);
        string? getPhotoPathById(int id);
        int? addCelebrity(Celebrity celebrity);
        bool delCelebrityById(int id);
        int? updCelebrityById(int id, Celebrity celebrity);
        int SaveChanges();
    }

    public class Repository : IRepository
    {
        public static string JSONFileName { get; } = "Celebrities.json";
        public string BasePath { get; }
        private List<Celebrity> AllCelebrity { get; set; }
        private Repository(string directoryPath)
        {
            BasePath = "D:/уник/4 сем/ТПвИ/lab04/ASPA/DAL004/" + directoryPath + "/Celebrities.json";
            if (File.Exists(BasePath))
            {
                var jsonData = File.ReadAllText(BasePath);
                AllCelebrity = JsonConvert.DeserializeObject<List<Celebrity>>(jsonData) ?? new List<Celebrity>();
            }
            else
            {
                AllCelebrity = new List<Celebrity>();
            }
        }
        public static Repository Create(string directoryName)
        {
            return new Repository(directoryName);
        }
        public Celebrity[] getAllCelebrities()
        {
            return AllCelebrity.ToArray();
        }
        public Celebrity? getCelebrityById(int id)
        {
            return AllCelebrity.FirstOrDefault(x => x.Id == id);
        }
        public Celebrity[] getCelebrityBySurname(string Surname)
        {
            return AllCelebrity.Where(x => x.Surname.Equals(Surname, StringComparison.OrdinalIgnoreCase)).ToArray();
        }
        public string? getPhotoPathById(int id)
        {
            return AllCelebrity.FirstOrDefault(y => y.Id == id)?.PhotoPath;
        }
        public void Dispose() { }

        public int? addCelebrity(Celebrity celebrity)
        {
            if (celebrity == null)
                return null;

            var maxId = AllCelebrity.Any() ? AllCelebrity.Max(x => x.Id) : 0;
            int newId = celebrity.Id != 0 && !AllCelebrity.Any(x => x.Id == celebrity.Id) ? celebrity.Id : maxId + 1;
            var newCelebrity = new Celebrity(newId, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
            AllCelebrity.Add(newCelebrity);
            return newId;
        }

        public bool delCelebrityById(int id)
        {
            var celebrity = AllCelebrity.FirstOrDefault(x => x.Id == id);
            if (celebrity == null) return false;

            AllCelebrity.Remove(celebrity);
            SaveChanges();
            return true;
        }

        public int? updCelebrityById(int id, Celebrity celebrity)
        {
            var index = AllCelebrity.FindIndex(x => x.Id == id);
            if (index == -1) return null;

            AllCelebrity[index] = celebrity;
            SaveChanges();

            return celebrity.Id;
        }

        public int SaveChanges()
        {
            var jsonData = JsonConvert.SerializeObject(AllCelebrity, Formatting.Indented);
            File.WriteAllText(BasePath, jsonData);
            return AllCelebrity.Count;
        }
    }
}
